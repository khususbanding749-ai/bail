"use strict";

var _fs = require("fs");
var _process = require("process");

const filePath = './index.js';

try {
  let content = (0, _fs.readFileSync)(filePath, 'utf8');

  // ═════════════════════════════════════════
  //  1. FIX IMPORT STATEMENTS
  // ═════════════════════════════════════════
  content = content.replace(
    /import \* as (\$protobuf) from/g,
    'import $1 from'
  );
  content = content.replace(
    /(['"])protobufjs\/minimal(['"])/g,
    '$1protobufjs/minimal.js$2'
  );

  // ═════════════════════════════════════════
  //  2. LONG HELPERS (Native BigInt)
  // ═════════════════════════════════════════
  const longToStringHelper =
    'function longToString(value, unsigned) {\n' +
    '\tif (typeof value === "string") return value;\n' +
    '\tif (typeof value === "number") return String(value);\n' +
    '\tif (typeof value === "bigint") return value.toString();\n' +
    '\tif (value && typeof value.low === "number" && typeof value.high === "number") {\n' +
    '\t\tconst lo = BigInt(value.low >>> 0);\n' +
    '\t\tconst hi = BigInt(value.high >>> 0);\n' +
    '\t\tconst combined = (hi << 32n) | lo;\n' +
    '\t\tif (!unsigned && value.high < 0) {\n' +
    '\t\t\treturn (combined - (1n << 64n)).toString();\n' +
    '\t\t}\n' +
    '\t\treturn combined.toString();\n' +
    '\t}\n' +
    '\treturn String(value);\n' +
    '}\n\n';

  const longToNumberHelper =
    'function longToNumber(value, unsigned) {\n' +
    '\tif (typeof value === "number") return value;\n' +
    '\tif (typeof value === "string") return Number(value);\n' +
    '\tif (typeof value === "bigint") return Number(value);\n' +
    '\tif (value && typeof value.low === "number" && typeof value.high === "number") {\n' +
    '\t\tconst lo = BigInt(value.low >>> 0);\n' +
    '\t\tconst hi = BigInt(value.high >>> 0);\n' +
    '\t\tconst combined = (hi << 32n) | lo;\n' +
    '\t\tif (!unsigned && value.high < 0) {\n' +
    '\t\t\treturn Number(combined - (1n << 64n));\n' +
    '\t\t}\n' +
    '\t\treturn Number(combined);\n' +
    '\t}\n' +
    '\treturn Number(value);\n' +
    '}\n\n';

  // ═════════════════════════════════════════
  //  3. INJECT HELPERS (flexible marker)
  // ═════════════════════════════════════════
  if (!content.includes('function longToString(')) {
    const markers = [
      'const $root = $protobuf.roots["default"] || ($protobuf.roots["default"] = {});\n\n',
      'const $root = $protobuf.roots["default"] || ($protobuf.roots["default"] = {});\r\n\r\n',
      'var $root = $protobuf.roots["default"] || ($protobuf.roots["default"] = {});\n\n',
    ];

    let injected = false;
    for (const marker of markers) {
      if (content.includes(marker)) {
        content = content.replace(marker, `${marker}${longToStringHelper}${longToNumberHelper}`);
        injected = true;
        break;
      }
    }

    // Fallback: inject sebelum "export"
    if (!injected) {
      const exportIdx = content.indexOf('\nexport ');
      if (exportIdx > 0) {
        content = content.slice(0, exportIdx) + '\n' +
                  longToStringHelper + longToNumberHelper +
                  content.slice(exportIdx);
        injected = true;
      }
    }

    if (!injected) {
      throw new Error('Marker longToString gak ketemu — cek struktur index.js');
    }
  } else {
    // Update helper kalau udah ada
    const longToStringRegex = /function longToString\(value, unsigned\) \{[\s\S]*?\n\}\n\n/;
    const longToNumberRegex = /function longToNumber\(value, unsigned\) \{[\s\S]*?\n\}\n\n/;
    if (longToStringRegex.test(content)) content = content.replace(longToStringRegex, longToStringHelper);
    if (longToNumberRegex.test(content)) content = content.replace(longToNumberRegex, longToNumberHelper);
  }

  // ═════════════════════════════════════════
  //  4. REPLACE LONG PATTERNS (multi-variant)
  // ═════════════════════════════════════════
  let replaced = 0;

  // Pattern A: d.X = o.longs === String ? $util.Long.prototype.toString.call(m.X) : ...
  content = content.replace(
    /([ \t]+d\.(\w+) = )o\.longs === String \? \$util\.Long\.prototype\.toString\.call\(m\.\2\)(, true)? : o\.longs === Number \? new \$util\.LongBits\(m\.\2\.low >>> 0, m\.\2\.high >>> 0\)\.toNumber\((true)?\) : m\.\2;/g,
    (_m, prefix, field, u1, u2) => {
      replaced++;
      const u = (u1 || u2) ? ', true' : '';
      return `${prefix}o.longs === String ? longToString(m.${field}${u}) : o.longs === Number ? longToNumber(m.${field}${u}) : m.${field};`;
    }
  );

  // Pattern B: tanpa 'd.' prefix
  content = content.replace(
    /o\.longs === String \? \$util\.Long\.prototype\.toString\.call\(m\.(\w+)(, true)?\) : o\.longs === Number \? new \$util\.LongBits\(m\.\1\.low >>> 0, m\.\1\.high >>> 0\)\.toNumber\((true)?\) : m\.\1/g,
    (_m, field, u1, u2) => {
      replaced++;
      const u = (u1 || u2) ? ', true' : '';
      return `o.longs === String ? longToString(m.${field}${u}) : o.longs === Number ? longToNumber(m.${field}${u}) : m.${field}`;
    }
  );

  // Pattern C: shortcut m.X.toString()
  content = content.replace(
    /o\.longs === String \? m\.(\w+)\.toString\(\) : o\.longs === Number \? new \$util\.LongBits\(m\.\1\.low >>> 0, m\.\1\.high >>> 0\)\.toNumber\((true)?\) : m\.\1/g,
    (_m, field, u1) => {
      replaced++;
      const u = u1 ? ', true' : '';
      return `o.longs === String ? longToString(m.${field}${u}) : o.longs === Number ? longToNumber(m.${field}${u}) : m.${field}`;
    }
  );

  // Pattern D: toLong generic
  content = content.replace(
    /\$util\.Long\.prototype\.toString\.call\((\w+)\.(\w+)(, true)?\)/g,
    (_m, obj, field, u1) => {
      replaced++;
      const u = u1 ? ', true' : '';
      return `longToString(${obj}.${field}${u})`;
    }
  );

  // Pattern E: LongBits toNumber generic
  content = content.replace(
    /new \$util\.LongBits\((\w+)\.(\w+)\.low >>> 0, \1\.\2\.high >>> 0\)\.toNumber\((true)?\)/g,
    (_m, obj, field, u1) => {
      replaced++;
      const u = u1 ? ', true' : '';
      return `longToNumber(${obj}.${field}${u})`;
    }
  );

  // ═════════════════════════════════════════
  //  5. VERIFIKASI
  // ═════════════════════════════════════════
  if (!content.includes('function longToString(')) {
    throw new Error('longToString GAK ke-inject');
  }
  if (!content.includes('function longToNumber(')) {
    throw new Error('longToNumber GAK ke-inject');
  }

  // ═════════════════════════════════════════
  //  6. WRITE FILE
  // ═════════════════════════════════════════
  (0, _fs.writeFileSync)(filePath, content, 'utf8');

  console.log(`✅ Fixed imports in ${filePath}`);
  console.log(`✅ Long helpers injected (BigInt native)`);
  console.log(`✅ ${replaced} pattern Long di-replace`);
  console.log(`✅ Support ALL message types: newsletter, interactive, button, list, dsb`);

} catch (error) {
  console.error(`❌ Error fixing imports: ${error.message}`);
  (0, _process.exit)(1);
}