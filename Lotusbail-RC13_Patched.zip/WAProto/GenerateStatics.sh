// build-proto.js
// Build script full: pbjs + pbts + fix-imports
const { execSync } = require('child_process');
const path = require('path');

const PROTO  = './WAProto.proto';
const OUT_JS = './index.js';
const OUT_D  = './index.d.ts';
const FIXER  = './fix-imports.js';

console.log('🔨 [1/3] Building JS dari proto...');
execSync(
  `yarn pbjs -t static-module --no-beautify -w es6 --no-bundle --no-delimited --no-verify --no-comments -o ${OUT_JS} ${PROTO}`,
  { stdio: 'inherit' }
);

console.log('🔨 [2/3] Building TypeScript defs...');
execSync(
  `yarn pbjs -t static-module --no-beautify -w es6 --no-bundle --no-delimited --no-verify ${PROTO} | yarn pbts --no-comments -o ${OUT_D} -`,
  { stdio: 'inherit', shell: true }
);

console.log('🔨 [3/3] Running fix-imports.js...');
execSync(`node ${FIXER}`, { stdio: 'inherit' });

console.log('\n✅ BUILD SELESAI');
console.log('📦 Output :', OUT_JS);
console.log('📦 Defs   :', OUT_D);